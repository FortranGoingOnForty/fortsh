# Fortsh - Fortran Shell

A modern Unix shell implementation written in Fortran 2018 that demonstrates Fortran's capability for system programming.

## Features

### 🔧 Advanced I/O & Process Management
- Pipes and pipeline processing
- Here-strings (`<<<`) and here-documents (`<<`)
- Process substitution (`<(command)`, `>(command)`)
- Enhanced command substitution with nesting support
- Coprocess support for bidirectional communication
- Brace expansion (`{a,b,c}`, `{1..10}`, `{a..z}`)
- Advanced signal handling with timeouts and traps

### 📜 Full Scripting Support
- For-in loops, while loops, and control flow
- Functions with local variables
- Variable expansion and environment management
- Conditional execution (if/then/else/fi)
- Advanced test operations with `[[ ]]` syntax
- Interactive input with `read` built-in
- Option parsing with `getopts`

### ⚙️ Job Control
- Background job execution (`&`)
- Suspend/resume functionality
- Process group management
- Built-in commands: `jobs`, `fg`, `bg`, `kill`, `wait`

### 🔍 Pattern Matching & Globbing
- Wildcard patterns: `*`, `?`, `[abc]`, `[a-z]`
- Recursive pattern matching algorithm
- Sorted glob expansion results
- Directory-aware pattern matching

### 📊 Performance Monitoring
- Real-time execution timing
- Memory allocation tracking
- Built-in performance commands (`perf`, `memory`)
- Memory pool optimization
- Runtime statistics and profiling

### 🛡️ Error Handling
- Comprehensive test suite
- Robust error categorization
- Memory leak prevention
- Signal handling and cleanup

### 💻 Built-in Commands

#### Core Built-ins
- **`cd`** - Change directory with `~` and `-` support
- **`pwd`** - Print working directory
- **`echo`** - Display text with escape sequence support
- **`printf`** - Formatted output with full format specifier support
- **`read`** - Interactive input with options (`-p`, `-t`, `-s`, `-r`, `-a`, `-n`, `-d`)
- **`export`** - Export variables to environment
- **`unset`** - Remove variables and functions
- **`set`** - Set shell options and positional parameters
- **`shift`** - Shift positional parameters

#### Test Operations
- **`test`** / **`[`** - Traditional test command
- **`[[ ]]`** - Advanced test operations with pattern matching
- **`true`** / **`false`** - Boolean commands

#### Job Control
- **`jobs`** - List active jobs
- **`fg`** - Bring job to foreground
- **`bg`** - Send job to background
- **`kill`** - Terminate processes
- **`wait`** - Wait for job completion

#### Directory Operations
- **`pushd`** - Push directory onto stack and change
- **`popd`** - Pop directory from stack and change
- **`dirs`** - Display directory stack

#### Command Information
- **`type`** - Display command type and location
- **`which`** - Locate command in PATH
- **`command`** - Execute command bypassing aliases/functions

#### Script Control
- **`exit`** - Exit shell with status code
- **`return`** - Return from function
- **`break`** - Break out of loops
- **`continue`** - Continue to next loop iteration
- **`source`** / **`.`** - Execute script in current context
- **`eval`** - Evaluate string as command
- **`exec`** - Replace shell with command
- **`getopts`** - Parse command options

#### Performance & Debugging
- **`perf`** - Performance monitoring control
- **`memory`** - Display memory usage statistics
- **`help`** - Display help information

## Quick Start

### Installation

#### From Repository (Recommended)
```bash
# Add repository
sudo wget -O /etc/yum.repos.d/fortsh.repo https://repos.musicsian.com/fortsh.repo

# Install fortsh  
sudo dnf install fortsh
```

#### Build from Source
```bash
git clone https://github.com/FortranGoingOnForty/fortsh.git
cd fortsh
make all
make dev-install
```

### Usage Examples

```bash
# Start the shell
fortsh

# Enable performance monitoring
export FORTSH_PERF=1
fortsh

# Basic scripting
for file in *.txt; do
    echo "Processing: $file"
done

# Job control
command &    # Background execution
jobs         # List active jobs
fg %1        # Bring job to foreground

# Pattern matching and expansion
echo *.{txt,log}         # Multiple extensions
echo test-[0-9]*         # Character ranges
echo {a,b,c}.txt         # Brace expansion
echo {1..10}             # Numeric ranges
echo file{01..05}.dat    # Zero-padded sequences

# Advanced testing
[[ -f "$file" && -r "$file" ]] && echo "Readable file"
[[ "$string" =~ ^[0-9]+$ ]] && echo "Number"
[[ "$var" == pattern* ]] && echo "Matches pattern"

# Interactive input
read -p "Enter name: " name
read -t 30 -p "Quick response (30s): " response
read -s -p "Password: " password

# Option parsing with getopts
while getopts "hvf:" opt; do
  case $opt in
    h) show_help ;;
    v) verbose=1 ;;
    f) file="$OPTARG" ;;
  esac
done

# Directory stack operations
pushd /tmp           # Change and push current dir
pushd ~/projects     # Stack: /tmp, ~
popd                 # Back to /tmp
dirs -v              # Show numbered stack

# Process substitution
diff <(sort file1) <(sort file2)
command > >(logger -t cmd)

# Command substitution with nesting
result=$(command1 $(command2 $(command3)))

# Coprocess communication
coproc sort
echo "data" >&${COPROC[1]}
read result <&${COPROC[0]}
```

### Performance Features

```bash
# Runtime performance monitoring
perf on              # Enable monitoring
perf                 # Show statistics
memory               # Memory usage info

# Example output:
# ====================================
# FORTSH PERFORMANCE STATISTICS  
# ====================================
# Uptime:           .002 seconds
# Total commands:   9
# Avg parse time:   .009 ms
# Avg exec time:    .115 ms
# Current memory:   4608 bytes
# Peak memory:      14592 bytes
```

## Architecture

Fortsh is built with a modular architecture:

- **Common**: Core types, error handling, performance monitoring
- **System**: OS interface layer, signal handling  
- **Parsing**: Command parsing, glob expansion
- **Execution**: Command execution, job control, built-ins
- **Scripting**: Variables, control flow, configuration
- **I/O**: Readline interface and input handling

## Requirements

- **Operating System**: Linux (RHEL 9, CentOS Stream 9, Rocky Linux 9, AlmaLinux 9, Fedora)
- **Architecture**: x86_64
- **Build Dependencies**: gfortran >= 11.0, make, gcc
- **Runtime Dependencies**: glibc

## Development

### Building
```bash
make all        # Build the shell
make test       # Run integration tests
make check      # Run comprehensive checks
make smoke-test # Basic functionality tests
```

### Packaging
```bash
make dist       # Create distribution tarball
make rpm        # Build RPM packages
```

### Installation
```bash
make install       # System-wide installation (/usr/local/bin)
make dev-install   # User installation (~/.local/bin)
make uninstall     # Remove installation
```

## Performance

Fortsh includes comprehensive performance monitoring:

- **Parsing**: ~0.009ms average per command
- **Execution**: ~0.115ms average per command  
- **Memory**: Automatic optimization with pools
- **Profiling**: Built-in timing and allocation tracking

## Testing

Comprehensive test suite with:
- Integration tests for all major features
- Memory leak detection
- Performance regression testing
- Error condition handling

```bash
./tests/integration_test.sh    # Full test suite
make smoke-test                # Quick verification
```

## License

MIT License - See LICENSE file for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes with tests
4. Submit a pull request

## Support

- **Issues**: https://github.com/FortranGoingOnForty/fortsh/issues
- **Documentation**: https://repos.musicsian.com/fortsh.html
- **Repository**: https://repos.musicsian.com/

---

*Fortsh demonstrates that Fortran is not just for scientific computing - it's capable of modern system programming and can compete with traditional system languages for shell implementation.*