! ==============================================================================
! Module: expansion
! Purpose: Parameter expansion and arithmetic operations
! ==============================================================================
module expansion
  use shell_types
  use variables
  use iso_fortran_env, only: output_unit, error_unit
  implicit none

contains

  ! Parameter expansion: ${var:offset:length}
  function parameter_expansion(shell, expression) result(expanded)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: expression
    character(len=2048) :: expanded
    
    character(len=256) :: var_name, operation, param1, param2
    character(len=1024) :: var_value
    integer :: colon_pos, dash_pos, plus_pos, percent_pos, hash_pos, slash_pos
    integer :: offset, length, i
    
    expanded = ''
    
    ! Remove ${ and }
    if (len_trim(expression) < 4) return
    var_name = expression(3:len_trim(expression)-1)
    
    ! Check for various expansion operations
    colon_pos = index(var_name, ':')
    dash_pos = index(var_name, '-')
    plus_pos = index(var_name, '+')
    percent_pos = index(var_name, '%')
    hash_pos = index(var_name, '#')
    slash_pos = index(var_name, '/')
    
    if (colon_pos > 0) then
      ! ${var:offset:length} substring expansion
      call parse_substring_expansion(var_name, operation, param1, param2)
      var_value = get_shell_variable(shell, trim(operation))
      
      if (len_trim(param1) > 0) then
        read(param1, *) offset
        if (len_trim(param2) > 0) then
          read(param2, *) length
          if (offset >= 0 .and. offset < len_trim(var_value)) then
            i = min(length, len_trim(var_value) - offset)
            expanded = var_value(offset+1:offset+i)
          end if
        else
          if (offset >= 0 .and. offset < len_trim(var_value)) then
            expanded = var_value(offset+1:)
          end if
        end if
      else
        expanded = var_value
      end if
      
    else if (dash_pos > 0) then
      ! ${var:-default} default value expansion
      operation = var_name(:dash_pos-1)
      param1 = var_name(dash_pos+2:)  ! Skip :-
      var_value = get_shell_variable(shell, trim(operation))
      
      if (len_trim(var_value) > 0) then
        expanded = trim(var_value)
      else
        expanded = trim(param1)
      end if
      
    else if (plus_pos > 0) then
      ! ${var:+alternative} alternative value expansion  
      operation = var_name(:plus_pos-1)
      param1 = var_name(plus_pos+2:)  ! Skip :+
      var_value = get_shell_variable(shell, trim(operation))
      
      if (len_trim(var_value) > 0) then
        expanded = trim(param1)
      else
        expanded = ''
      end if
      
    else if (hash_pos > 0) then
      ! ${#var} length expansion
      operation = var_name(hash_pos+1:)
      var_value = get_shell_variable(shell, trim(operation))
      write(expanded, '(I0)') len_trim(var_value)
      
    else
      ! Simple variable expansion
      var_value = get_shell_variable(shell, trim(var_name))
      expanded = trim(var_value)
    end if
    
  end function

  subroutine parse_substring_expansion(input, var_name, offset_str, length_str)
    character(len=*), intent(in) :: input
    character(len=*), intent(out) :: var_name, offset_str, length_str
    integer :: first_colon, second_colon
    
    var_name = ''
    offset_str = ''
    length_str = ''
    
    first_colon = index(input, ':')
    if (first_colon == 0) return
    
    var_name = input(:first_colon-1)
    
    second_colon = index(input(first_colon+1:), ':')
    if (second_colon > 0) then
      second_colon = first_colon + second_colon
      offset_str = input(first_colon+1:second_colon-1)
      length_str = input(second_colon+1:)
    else
      offset_str = input(first_colon+1:)
    end if
  end subroutine

  ! Arithmetic expansion: $((expression))
  function arithmetic_expansion(expression) result(result_value)
    character(len=*), intent(in) :: expression
    character(len=32) :: result_value
    
    character(len=256) :: expr
    integer :: result_int, i, j, num1, num2
    character(len=32) :: num1_str, num2_str
    character :: op
    
    result_value = '0'
    
    ! Remove $(( and ))
    if (len_trim(expression) < 6) return
    expr = expression(4:len_trim(expression)-2)
    
    ! Simple arithmetic parser for basic operations
    call parse_arithmetic_expression(trim(expr), num1, op, num2)
    
    select case (op)
    case ('+')
      result_int = num1 + num2
    case ('-')
      result_int = num1 - num2
    case ('*')
      result_int = num1 * num2
    case ('/')
      if (num2 /= 0) then
        result_int = num1 / num2
      else
        result_int = 0
      end if
    case ('%')
      if (num2 /= 0) then
        result_int = mod(num1, num2)
      else
        result_int = 0
      end if
    case default
      result_int = num1
    end select
    
    write(result_value, '(I0)') result_int
  end function

  subroutine parse_arithmetic_expression(expr, num1, op, num2)
    character(len=*), intent(in) :: expr
    integer, intent(out) :: num1, num2
    character, intent(out) :: op
    
    integer :: i, op_pos
    character(len=32) :: num1_str, num2_str
    
    num1 = 0
    num2 = 0
    op = '+'
    
    ! Find operator
    op_pos = 0
    do i = 1, len_trim(expr)
      if (index('+-*/%', expr(i:i)) > 0) then
        op_pos = i
        op = expr(i:i)
        exit
      end if
    end do
    
    if (op_pos > 1) then
      num1_str = expr(:op_pos-1)
      num2_str = expr(op_pos+1:)
      
      read(num1_str, *, iostat=i) num1
      if (i /= 0) num1 = 0
      
      read(num2_str, *, iostat=i) num2  
      if (i /= 0) num2 = 0
    else
      read(expr, *, iostat=i) num1
      if (i /= 0) num1 = 0
    end if
  end subroutine

  ! Enhanced variable expansion with array and parameter support
  subroutine enhanced_expand_variables(input, expanded, shell)
    character(len=*), intent(in) :: input
    character(len=:), allocatable, intent(out) :: expanded
    type(shell_state_t), intent(in) :: shell
    
    character(len=4096) :: result
    integer :: i, start_pos, end_pos, bracket_count
    character(len=256) :: var_expr
    character(len=2048) :: var_value
    logical :: in_expansion
    
    result = ''
    i = 1
    
    do while (i <= len_trim(input))
      if (i < len_trim(input) - 2 .and. input(i:i+2) == '$((') then
        ! Arithmetic expansion $((expr))
        start_pos = i
        bracket_count = 2
        i = i + 3
        
        do while (i <= len_trim(input) .and. bracket_count > 0)
          if (input(i:i) == '(') bracket_count = bracket_count + 1
          if (input(i:i) == ')') bracket_count = bracket_count - 1
          i = i + 1
        end do
        
        if (bracket_count == 0) then
          var_expr = input(start_pos:i-1)
          var_value = arithmetic_expansion(var_expr)
          result = trim(result) // trim(var_value)
        end if
        
      else if (i < len_trim(input) - 1 .and. input(i:i+1) == '${') then
        ! Parameter expansion ${var}
        start_pos = i
        bracket_count = 1
        i = i + 2
        
        do while (i <= len_trim(input) .and. bracket_count > 0)
          if (input(i:i) == '{') bracket_count = bracket_count + 1
          if (input(i:i) == '}') bracket_count = bracket_count - 1
          i = i + 1
        end do
        
        if (bracket_count == 0) then
          var_expr = input(start_pos:i-1)
          var_value = parameter_expansion(shell, var_expr)
          result = trim(result) // trim(var_value)
        end if
        
      else if (input(i:i) == '$') then
        ! Simple variable expansion $var
        start_pos = i + 1
        i = i + 1
        
        do while (i <= len_trim(input) .and. (is_alnum(input(i:i)) .or. input(i:i) == '_'))
          i = i + 1
        end do
        
        if (i > start_pos) then
          var_expr = input(start_pos:i-1)
          var_value = get_shell_variable(shell, trim(var_expr))
          result = trim(result) // trim(var_value)
        else
          result = trim(result) // '$'
        end if
        
      else
        result = trim(result) // input(i:i)
        i = i + 1
      end if
    end do
    
    expanded = trim(result)
  end subroutine

  function is_alnum(c) result(is_valid)
    character, intent(in) :: c
    logical :: is_valid
    
    is_valid = (c >= 'a' .and. c <= 'z') .or. &
               (c >= 'A' .and. c <= 'Z') .or. &
               (c >= '0' .and. c <= '9')
  end function

end module expansion